package com.barclays.homeloan.utils;

public class TenureReqUtil {
	
	int months;


	public int getMonths() {
		return months;
	}

	public void setMonths(int months) {
		this.months = months;
	}

	public TenureReqUtil(int months) {
		this.months = months;
	}
}
