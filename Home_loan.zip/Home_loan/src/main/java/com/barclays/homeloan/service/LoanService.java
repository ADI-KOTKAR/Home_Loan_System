package com.barclays.homeloan.service;

import com.barclays.homeloan.entity.Loan;

public interface LoanService {
	
	public Loan getLoanById(int id);
}
